﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Project_ITLab.Models.Domain;

namespace Project_ITLab.Data {
    public class DataInit {
        private readonly Context context;
        private readonly UserManager<IdentityUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;

        public DataInit(Context con, UserManager<IdentityUser> userMan, RoleManager<IdentityRole> roleMan) {
            context = con;
            userManager = userMan ?? throw new ArgumentException("Error user manager ItLabContext");
            roleManager = roleMan ?? throw new ArgumentException("Error role manager ItLabContext");
        }

        public async Task InitAsync() {
            context.Database.EnsureDeleted();
            if (context.Database.EnsureCreated()) {
                InitData();
                await InitializeRoles();
                await InitializeUsers();
            }
        }

        private async Task InitializeRoles() {
            string[] roles = { Role.HeadAdmin, Role.Admin, Role.User };

            foreach (var role in roles)
                if (!await roleManager.RoleExistsAsync(role))
                    await roleManager.CreateAsync(new IdentityRole(role));

        }

        private async Task InitializeUsers() {
            const string password = "password";
            await CreateUser("nicklersberghe", password, Role.HeadAdmin);
            await CreateUser("dzhemaptula", password, Role.Admin);
            await CreateUser("tijlzwartjes", password, Role.Admin);
            await CreateUser("jannevschep", password, Role.Admin);
            await CreateUser("josephstalin", password, Role.User);
            await CreateUser("johncena", password, Role.User);
        }

        private async Task CreateUser(string username, string password, string role) {
            var user = new IdentityUser { UserName = username };
            var result = await userManager.CreateAsync(user, password);
            if (result.Succeeded) {
                var createdUser = await userManager.FindByNameAsync(user.UserName);
                await userManager.AddToRoleAsync(createdUser, role);
            }
        }

        private void InitData() {
            var Users = context.Users;
            var Sessions = context.Sessions;

            User us1 = new User("Dzhem", "Aptula", "1122642588674");
            User us2 = new User("Nick", "Lersberghe", "1122582892039");
            Users.Add(us1);
            Users.Add(us2);
            Users.Add(new User("Janne", "Vschep", "1117253563394"));
            Users.Add(new User("Tijl", "Zwartjes"));
            Users.Add(new User("John", "Cena"));
            Users.Add(new User("Billie", "Eilish"));
            Users.Add(new User("Joseph", "Stalin"));
            Users.Add(new User("Napoleon", "Bonaparte"));
            Users.Add(new User("Post", "Malone"));
            Users.Add(new User("Lil", "Pump"));

            context.SaveChanges();

            var dzhem = Users.Single(s => s.FirstName == "Dzhem");
            var nick = Users.Single(s => s.FirstName == "Nick");
            var janne = Users.Single(s => s.FirstName == "Janne");
            var tijl = Users.Single(s => s.FirstName == "Tijl");

            Session testSesh = new Session(tijl, DateTime.Now, DateTime.Now.AddMinutes(60), "Github", "C1024");
            testSesh.RegisterUser(us1);
            testSesh.RegisterUser(us2);

            Sessions.Add(new Session(dzhem, DateTime.Now, DateTime.Now.AddHours(1), "Cyber Security", "B2014"));
            Sessions.Add(new Session(nick, DateTime.Now.AddMinutes(30), DateTime.Now.AddMinutes(60), "Relaxing", "D3001"));
            Sessions.Add(testSesh);
            Sessions.Add(new Session(janne, new DateTime(2020, 2, 16, 12, 30, 0), new DateTime(2020, 2, 16, 13, 30, 0), "Learn to learn", "C2034"));
            Sessions.Add(new Session(dzhem, new DateTime(2020, 3, 5, 20, 0, 0), new DateTime(2020, 3, 5, 21, 0, 0), "Explore your inner peace", "B0010"));
            Sessions.Add(new Session(nick, new DateTime(2020, 3, 10, 20, 0, 0), new DateTime(2020, 3, 10, 21, 0, 0), "Anime", "D2014"));
            Sessions.Add(new Session(janne, new DateTime(2020, 3, 1, 15, 0, 0), new DateTime(2020, 3, 1, 18, 0, 0), "Astrology", "B1024"));
            Sessions.Add(new Session(tijl, new DateTime(2020, 1, 25, 20, 0, 0), new DateTime(2020, 1, 25, 21, 0, 0), "Science evening", "C3028"));
            Sessions.Add(new Session(dzhem, new DateTime(2020, 2, 5, 20, 0, 0), new DateTime(2020, 2, 5, 21, 0, 0), "Hacking", "B3004"));
            Sessions.Add(new Session(nick, new DateTime(2020, 2, 15, 20, 0, 0), new DateTime(2020, 2, 15, 21, 0, 0), "Filmography", "D0004"));


            context.SaveChanges();
        }
    }
}
