﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_ITLab.Models.Domain {
    public static class Role {
        public const string HeadAdmin = "HeadAdmin";
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
